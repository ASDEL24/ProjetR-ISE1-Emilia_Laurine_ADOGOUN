# Charger les packages nécessaires
library(sf)
library(ggplot2)
library(dplyr)
library(shiny)
library(leaflet)
library(plotly)
library(rnaturalearth)
library(rnaturalearthdata)
library(dbscan)
library(cluster)
library(shinydashboard)


# Chargement des données géographiques
#world_sf = st_read("World WGS84/Pays_WGS84.shp")
#world_sf <- mutate(world_sf, NOM = ifelse(NOM == "Gambia, The", "Gambia", NOM))

base<-read.csv("ACLED-Western_Africa.csv")

# Clusterisation des données
clusters <- dbscan(base[, c("longitude", "latitude")], eps = 0.1, minPts = 5)
base$cluster <- as.factor(clusters$cluster)

# Définition des couleurs personnalisées
couleur_principale <- "#F090FF"  # Bleu ciel
couleur_fond <- "#FFFFE0"       # Jaune clair

ui <- dashboardPage(
  dashboardHeader(title = "West Africa events Map"),
  
  dashboardSidebar(
    # Couleurs de fond de la sidebar
    style = sprintf(couleur_fond),
    
    sidebarMenu(
      # Couleur du texte du menu
      style = sprintf(couleur_principale),
      
      menuItem("Carte du monde par évènements", icon = icon("globe-americas"), tabName = "map_tab"),
      menuItem("Filtrage des événements", icon = icon("filter"), tabName = "filter_tab")
    )
  ),
  
  dashboardBody(
    # Thème du tableau de bord
    skin = "red",
    
    # Couleur de fond du body
    style = sprintf("background-color: %s;", couleur_fond),
    
    tabItems(
      # Onglet - Carte du monde par évènements
      tabItem(
        tabName = "map_tab",
        fluidRow(
          box(
            title = "Choisir un pays",
            # Couleur de fond de la box
            style = sprintf("background-color: %s;", couleur_fond),
            
            selectInput(
              inputId = "event_filter",
              label = "Sélectionnez un pays",
              choices = c(unique(base$pays)),
              selected = c(unique(base$pays))[sample(1:length(unique(base$pays)), 1)],
              multiple = TRUE
            ),
            br(),
          ),
          box(
            title = "Carte du monde",
            # Couleur de fond de la box
            style = sprintf("background-color: %s;", couleur_fond),
            
            leafletOutput("map")
          )
        )
      ),
      
      # Onglet - Filtrage des événements
      tabItem(
        tabName = "filter_tab",
        fluidRow(
          box(
            title = "Filtrer les événements",
            # Couleur de fond de la box
            style = sprintf("background-color: %s;", couleur_fond),
            
            selectInput(
              inputId = "country_filter",
              label = "Sélectionnez un pays",
              choices = c(unique(base$pays)),
              selected = c(unique(base$pays))[sample(1:length(unique(base$pays)), 1)],
              multiple = TRUE
            ),
            br(),
            selectInput(
              inputId = "event_type_filter",
              label = "Sélectionnez un type d'évenement",
              choices = c(unique(base$type)),
              selected = "Protests",
              multiple = TRUE
            ),
            br(),
            selectInput(
              inputId = "year_filter",
              label = "Sélectionnez une annee",
              choices = c(unique(base$annee)),
              selected = "2023",
              multiple = TRUE
            )
          ),
          box(
            title = "Carte filtrée",
            # Couleur de fond de la box
            style = sprintf("background-color: %s;", couleur_fond),
            
            leafletOutput("filtered_map")
          )
        )
      )
    )
  )
)

server <- function(input, output, session) {
  # Carte de l'Afrique de l'Ouest
  # Carte par pays
  output$map <- renderLeaflet({
    filtered <- subset(base, pays %in% input$event_filter)
    
    leaflet(filtered) %>%
      addTiles() %>%
      addCircleMarkers(
        lng = ~longitude,
        lat = ~latitude,
        radius = 5,
        color = ~cluster,
        opacity = 0.8,
        fillOpacity = 0.8,
        label = ~paste("Pays :", pays, "<br>Type :", type, "<br>Année :", annee),
        clusterOptions = markerClusterOptions()
      )
  })
  
  # Filtrage des événements
  filteredData <- reactive({
    subset(base, pays == c(input$country_filter) & type == c(input$event_type_filter) & annee == c(input$year_filter))
  })
  
  # Carte filtrée
  output$filtered_map <- renderLeaflet({
    filtered <- filteredData()
    
    leaflet(filtered) %>%
      addTiles() %>%
      addCircleMarkers(
        lng = ~longitude,
        lat = ~latitude,
        radius = 5,
        color = ~cluster,
        opacity = 0.8,
        fillOpacity = 0.8,
        label = ~paste("Pays :", pays, "<br>Type :", type, "<br>Année :", annee),
        clusterOptions = markerClusterOptions()
      )
  })
}

shinyApp(ui = ui, server = server)